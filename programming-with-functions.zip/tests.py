"""
The test script for the course project.


Author: DJ Williams (DWJ)
Date: May 06, 2025
"""

import introcs
import funcs 

def test_matching_parens():
    """
    Test procedure for matching_parens
    """
    print('Testing matching_parens')

    #Test case 1
    result = funcs.matching_parens('Are (you) there') 
    introcs.assert_true(result)   
    #Test case 2
    result = funcs.matching_parens('where (did) (you) go') 
    introcs.assert_true(result)
    #Test case 3
    result = funcs.matching_parens('count the numbers ((1 2)(3) 4)')
    introcs.assert_true(result)
    #Test case 4
    result = funcs.matching_parens('(where the red fern grows)')
    introcs.assert_true(result)
    #Test case 5'
    result = funcs.matching_parens('this is (not (closed)')
    introcs.assert_false(result)
    #Test case 6
    result = funcs.matching_parens('(()())')
    introcs.assert_true(result)
    #Test case 7
    result = funcs.matching_parens(")(")
    introcs.assert_false(result)

def test_first_in_parens():
    """
    Test procedure for first_in_parens
    """
    print('Testing first_in_parens')
    
    #Test case 1
    result = funcs.first_in_parens('Are (you) there') 
    introcs.assert_equals('you', result)   

    #Test case 2
    result = funcs.first_in_parens('where (did) (you) go')
    introcs.assert_equals('did', result)

    #Test case 3
    result = funcs.first_in_parens('count the numbers ((1 2)(3) 4)')
    introcs.assert_equals('(1 2', result)

    #Test case 4 
    result = funcs.first_in_parens('(where the red fern grows)')
    introcs.assert_equals('where the red fern grows', result)     

    #Test case 5
    result = funcs.first_in_parens('and where have you been ()')
    introcs.assert_equals('', result)        

#Script code

test_matching_parens()
test_first_in_parens()
print('Module funcs is working correctly')